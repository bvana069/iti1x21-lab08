public class TestL08 {

  public static void main(String[] args) {
    TestUtils.runClass(TestL8Customer.class);
    TestUtils.runClass(TestL8Cashier.class);
  }

}
